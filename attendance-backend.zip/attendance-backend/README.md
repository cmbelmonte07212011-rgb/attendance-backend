# Attendance Backend - Java Spring Boot

A lightweight cloud backup server for the Class Attendance app.
Saves all data (sections, students, attendance, QR, history) as JSON files on the server.

---

## Requirements
- Java 17+
- Maven 3.8+

## Run the server

```bash
cd attendance-backend
mvn spring-boot:run
```

Server starts at: http://localhost:8080

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | /api/ping | Health check |
| POST | /api/backup/{schoolId} | Push ALL localStorage data to server |
| GET | /api/backup/{schoolId} | Pull ALL data back to restore |
| GET | /api/sections/{schoolId} | Get sections |
| GET | /api/students/{schoolId}/{sectionId} | Get students in a section |
| GET | /api/attendance/{schoolId}/{sectionId} | Get today's attendance |
| GET | /api/history/{schoolId}/{sectionId}/{date} | Get attendance for a date |
| GET | /api/data/{key} | Get any key |
| POST | /api/data/{key} | Set any key |
| DELETE | /api/data/{key} | Delete a key |

---

## Connecting to the Frontend

In the attendance HTML file, the **☁ Sync** button:
1. **Push to Cloud** — sends all localStorage data to the server
2. **Pull from Cloud** — restores all data from server back to localStorage

Change the backend URL in the HTML if you deploy to a server:
```javascript
const BACKEND = 'http://localhost:8080'; // Change this to your server IP/domain
```

---

## Deploying to a real server

1. Build the JAR:
```bash
mvn clean package
```

2. Run the JAR:
```bash
java -jar target/attendance-backend-1.0.0.jar
```

3. For production, deploy behind Nginx or on a VPS (DigitalOcean, Railway, Render).

---

## Data Storage

All data saved as JSON files in the `/data` folder beside the JAR.
- `backup_{schoolId}.json` — full sync backup
- Individual key files for fine-grained access

