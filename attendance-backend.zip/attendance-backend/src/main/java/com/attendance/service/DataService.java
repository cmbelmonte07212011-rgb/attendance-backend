package com.attendance.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.util.*;

@Service
public class DataService {

    private static final String DATA_DIR = "data/";
    private final ObjectMapper mapper = new ObjectMapper();

    public DataService() {
        new File(DATA_DIR).mkdirs();
    }

    private File file(String key) {
        // Sanitize key to safe filename
        String safe = key.replaceAll("[^a-zA-Z0-9_\\-]", "_");
        return new File(DATA_DIR + safe + ".json");
    }

    public String get(String key) throws IOException {
        File f = file(key);
        if (!f.exists()) return null;
        return Files.readString(f.toPath());
    }

    public void set(String key, String value) throws IOException {
        Files.writeString(file(key).toPath(), value);
    }

    public void delete(String key) {
        file(key).delete();
    }

    public List<String> listKeys(String prefix) {
        File dir = new File(DATA_DIR);
        String safePrefix = prefix.replaceAll("[^a-zA-Z0-9_\\-]", "_");
        List<String> keys = new ArrayList<>();
        File[] files = dir.listFiles();
        if (files == null) return keys;
        for (File f : files) {
            String name = f.getName().replace(".json", "");
            if (name.startsWith(safePrefix)) {
                keys.add(name);
            }
        }
        return keys;
    }

    // Full backup: save entire localStorage dump as one file
    public void saveBackup(String schoolId, Map<String, Object> allData) throws IOException {
        String json = mapper.writeValueAsString(allData);
        Files.writeString(
            Paths.get(DATA_DIR + "backup_" + schoolId + ".json"),
            json
        );
    }

    public Map<String, Object> loadBackup(String schoolId) throws IOException {
        File f = new File(DATA_DIR + "backup_" + schoolId + ".json");
        if (!f.exists()) return new HashMap<>();
        return mapper.readValue(f, Map.class);
    }
}
