package com.attendance.controller;

import com.attendance.service.DataService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Allow frontend to call from any origin
public class AttendanceController {

    private final DataService dataService;
    private final ObjectMapper mapper = new ObjectMapper();

    public AttendanceController(DataService dataService) {
        this.dataService = dataService;
    }

    // ── HEALTH CHECK ──
    @GetMapping("/ping")
    public ResponseEntity<Map<String, String>> ping() {
        return ok(Map.of("status", "ok", "message", "Attendance backend running"));
    }

    // ── KEY-VALUE STORE (mirrors localStorage) ──

    @GetMapping("/data/{key}")
    public ResponseEntity<Map<String, Object>> getData(@PathVariable String key) {
        try {
            String val = dataService.get(key);
            if (val == null) return ResponseEntity.notFound().build();
            return ok(Map.of("key", key, "value", val));
        } catch (Exception e) {
            return error(e);
        }
    }

    @PostMapping("/data/{key}")
    public ResponseEntity<Map<String, Object>> setData(
            @PathVariable String key,
            @RequestBody Map<String, Object> body) {
        try {
            String value = mapper.writeValueAsString(body.get("value"));
            // If value is already a string (plain JSON string), unwrap it
            Object raw = body.get("value");
            String toSave = (raw instanceof String) ? (String) raw : mapper.writeValueAsString(raw);
            dataService.set(key, toSave);
            return ok(Map.of("key", key, "saved", true));
        } catch (Exception e) {
            return error(e);
        }
    }

    @DeleteMapping("/data/{key}")
    public ResponseEntity<Map<String, Object>> deleteData(@PathVariable String key) {
        try {
            dataService.delete(key);
            return ok(Map.of("key", key, "deleted", true));
        } catch (Exception e) {
            return error(e);
        }
    }

    @GetMapping("/data")
    public ResponseEntity<Map<String, Object>> listKeys(
            @RequestParam(defaultValue = "") String prefix) {
        try {
            List<String> keys = dataService.listKeys(prefix);
            return ok(Map.of("keys", keys));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── FULL BACKUP SYNC ──
    // Frontend sends ALL localStorage keys at once → saved as one backup file

    @PostMapping("/backup/{schoolId}")
    public ResponseEntity<Map<String, Object>> saveBackup(
            @PathVariable String schoolId,
            @RequestBody Map<String, Object> allData) {
        try {
            dataService.saveBackup(schoolId, allData);
            return ok(Map.of(
                "saved", true,
                "schoolId", schoolId,
                "keys", allData.size(),
                "timestamp", new Date().toString()
            ));
        } catch (Exception e) {
            return error(e);
        }
    }

    @GetMapping("/backup/{schoolId}")
    public ResponseEntity<Map<String, Object>> loadBackup(@PathVariable String schoolId) {
        try {
            Map<String, Object> data = dataService.loadBackup(schoolId);
            return ok(Map.of(
                "schoolId", schoolId,
                "data", data,
                "keys", data.size()
            ));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── SECTIONS ──
    @GetMapping("/sections/{schoolId}")
    public ResponseEntity<Map<String, Object>> getSections(@PathVariable String schoolId) {
        try {
            String val = dataService.get("secs3_" + schoolId);
            return ok(Map.of("sections", val != null ? val : "[]"));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── STUDENTS per section ──
    @GetMapping("/students/{schoolId}/{sectionId}")
    public ResponseEntity<Map<String, Object>> getStudents(
            @PathVariable String schoolId,
            @PathVariable String sectionId) {
        try {
            String val = dataService.get("stu3_" + schoolId + "_" + sectionId);
            return ok(Map.of("students", val != null ? val : "[]"));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── ATTENDANCE per section ──
    @GetMapping("/attendance/{schoolId}/{sectionId}")
    public ResponseEntity<Map<String, Object>> getAttendance(
            @PathVariable String schoolId,
            @PathVariable String sectionId) {
        try {
            String val = dataService.get("at3_" + schoolId + "_" + sectionId);
            return ok(Map.of("attendance", val != null ? val : "[]"));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── HISTORY per section + date ──
    @GetMapping("/history/{schoolId}/{sectionId}/{date}")
    public ResponseEntity<Map<String, Object>> getHistory(
            @PathVariable String schoolId,
            @PathVariable String sectionId,
            @PathVariable String date) {
        try {
            String val = dataService.get("hist_" + schoolId + "_" + sectionId + "_" + date);
            return ok(Map.of("history", val != null ? val : "[]", "date", date));
        } catch (Exception e) {
            return error(e);
        }
    }

    // ── HELPERS ──
    private ResponseEntity<Map<String, Object>> ok(Map<String, Object> body) {
        return ResponseEntity.ok(body);
    }

    private ResponseEntity<Map<String, Object>> error(Exception e) {
        return ResponseEntity.status(500).body(Map.of("error", e.getMessage()));
    }
}
